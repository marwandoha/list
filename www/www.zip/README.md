DataBoundApplication
====================

An application that is bound to a real data service, displays list and detail views, and allows end users to search records. Follow the tutorial in PhoneJS documentation (http://phonejs.devexpress.com/Documentation/Tutorial/Getting_Started/Data-Bound_Application) to reproduce this application and understand the basics.
